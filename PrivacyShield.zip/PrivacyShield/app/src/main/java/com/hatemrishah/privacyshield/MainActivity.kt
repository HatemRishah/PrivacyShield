package com.hatemrishah.privacyshield

import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var btnToggleFull: Button
    private lateinit var btnToggleNotif: Button
    private lateinit var btnOff: Button
    private lateinit var seekIntensity: SeekBar
    private lateinit var tvStatus: TextView
    private lateinit var tvMode: TextView

    companion object {
        const val PREFS_NAME = "PrivacyShieldPrefs"
        const val KEY_MODE = "mode"
        const val KEY_INTENSITY = "intensity"
        const val MODE_OFF = "off"
        const val MODE_FULL = "full"
        const val MODE_NOTIF = "notif"
        const val REQUEST_OVERLAY = 1001
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)

        initViews()
        setupListeners()
        updateUI()
    }

    private fun initViews() {
        btnToggleFull = findViewById(R.id.btnToggleFull)
        btnToggleNotif = findViewById(R.id.btnToggleNotif)
        btnOff = findViewById(R.id.btnOff)
        seekIntensity = findViewById(R.id.seekIntensity)
        tvStatus = findViewById(R.id.tvStatus)
        tvMode = findViewById(R.id.tvMode)

        seekIntensity.max = 100
        seekIntensity.progress = prefs.getInt(KEY_INTENSITY, 70)
    }

    private fun setupListeners() {
        btnToggleFull.setOnClickListener {
            if (!hasOverlayPermission()) {
                requestOverlayPermission()
                return@setOnClickListener
            }
            setMode(MODE_FULL)
        }

        btnToggleNotif.setOnClickListener {
            if (!hasOverlayPermission()) {
                requestOverlayPermission()
                return@setOnClickListener
            }
            setMode(MODE_NOTIF)
        }

        btnOff.setOnClickListener {
            setMode(MODE_OFF)
        }

        seekIntensity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                prefs.edit().putInt(KEY_INTENSITY, progress).apply()
                // Live update if service running
                val currentMode = prefs.getString(KEY_MODE, MODE_OFF)
                if (currentMode != MODE_OFF) {
                    sendCommandToService(currentMode ?: MODE_OFF)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }

    private fun setMode(mode: String) {
        prefs.edit().putString(KEY_MODE, mode).apply()
        sendCommandToService(mode)
        updateUI()
    }

    private fun sendCommandToService(mode: String) {
        val intent = Intent(this, OverlayService::class.java).apply {
            putExtra("mode", mode)
            putExtra("intensity", prefs.getInt(KEY_INTENSITY, 70))
        }
        if (mode == MODE_OFF) {
            stopService(intent)
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
        }
    }

    private fun updateUI() {
        val mode = prefs.getString(KEY_MODE, MODE_OFF)
        when (mode) {
            MODE_FULL -> {
                tvStatus.text = "🟢 ACTIVE"
                tvMode.text = "Mode: Full Screen Privacy"
                tvStatus.setTextColor(getColor(R.color.green))
            }
            MODE_NOTIF -> {
                tvStatus.text = "🟡 ACTIVE"
                tvMode.text = "Mode: Notifications Only"
                tvStatus.setTextColor(getColor(R.color.yellow))
            }
            else -> {
                tvStatus.text = "🔴 OFF"
                tvMode.text = "Mode: Disabled"
                tvStatus.setTextColor(getColor(R.color.red))
            }
        }
    }

    private fun hasOverlayPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else true
    }

    private fun requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, REQUEST_OVERLAY)
            Toast.makeText(this, "Please enable 'Draw over other apps' permission", Toast.LENGTH_LONG).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_OVERLAY) {
            if (hasOverlayPermission()) {
                Toast.makeText(this, "Permission granted! You can now activate Privacy Shield.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        updateUI()
    }
}
