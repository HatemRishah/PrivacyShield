# 🛡️ Privacy Shield — Build Guide
### Coded By: Hatem Rishah

---

## What This App Does
- Simulates Samsung S26 Ultra's privacy screen on ANY Android device
- Dark gradient overlay blocks side-angle viewing (shoulder surfing)
- Two modes: Full Screen OR Notifications Only
- Quick Settings tile in notification panel for instant toggle
- Runs in background after you close the app
- Auto-restarts on device reboot

---

## How to Build the APK

### Requirements
- Android Studio (free): https://developer.android.com/studio
- Android phone with USB debugging enabled

### Steps

1. **Open Android Studio**
   - Click "Open" and select the `PrivacyShield` folder

2. **Wait for Gradle sync**
   - Android Studio will auto-download all dependencies (~2 mins)

3. **Build the APK**
   - Menu → Build → Build Bundle(s) / APK(s) → Build APK(s)
   - APK will be at: `app/build/outputs/apk/debug/app-debug.apk`

4. **Install on your phone**
   - Connect phone via USB
   - Click the ▶️ Run button OR
   - Transfer the APK file to your phone and install it manually

---

## First Time Setup on Phone

1. Open **Privacy Shield** app
2. It will ask for **"Draw over other apps"** permission
   - Tap "Allow" — this is required for the overlay to work
3. Pull down your notification panel → tap edit → find "Privacy Shield" tile → drag it to your quick tiles

---

## How to Use

| Action | How |
|--------|-----|
| Full screen privacy | Tap "Full Screen Privacy" button |
| Notifications only | Tap "Notifications Only" button |
| Quick toggle | Pull down panel → tap Privacy Shield tile |
| Adjust intensity | Use the slider in the app |
| Turn off | Tap "Turn Off" or tap tile twice |

---

## Tile Cycling
Tapping the Quick Settings tile cycles through:
**OFF → Full Screen → Notifications Only → OFF**

---

Samsung SUCKS 💀
Coded By : Hatem Rishah
