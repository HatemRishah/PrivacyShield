package com.hatemrishah.privacyshield

import android.content.Context
import android.graphics.*
import android.view.View

class PrivacyOverlayView(
    context: Context,
    private val intensity: Int,
    private val fullScreen: Boolean
) : View(context) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val w = width.toFloat()
        val h = height.toFloat()

        if (w == 0f || h == 0f) return

        // Calculate alpha based on intensity (0-100 → 80-220 alpha range)
        val baseAlpha = (80 + (intensity / 100f) * 140).toInt().coerceIn(80, 220)

        // --- EFFECT 1: Side darkness gradients (simulate narrow viewing angle) ---
        // Left edge gradient
        val leftGradient = LinearGradient(
            0f, 0f, w * 0.35f, 0f,
            intArrayOf(
                Color.argb(baseAlpha, 0, 0, 0),
                Color.argb(baseAlpha / 4, 0, 0, 0),
                Color.TRANSPARENT
            ),
            floatArrayOf(0f, 0.6f, 1f),
            Shader.TileMode.CLAMP
        )
        paint.shader = leftGradient
        canvas.drawRect(0f, 0f, w * 0.35f, h, paint)

        // Right edge gradient
        val rightGradient = LinearGradient(
            w, 0f, w * 0.65f, 0f,
            intArrayOf(
                Color.argb(baseAlpha, 0, 0, 0),
                Color.argb(baseAlpha / 4, 0, 0, 0),
                Color.TRANSPARENT
            ),
            floatArrayOf(0f, 0.6f, 1f),
            Shader.TileMode.CLAMP
        )
        paint.shader = rightGradient
        canvas.drawRect(w * 0.65f, 0f, w, h, paint)

        // Top edge gradient (always)
        val topGradient = LinearGradient(
            0f, 0f, 0f, h * 0.15f,
            intArrayOf(
                Color.argb((baseAlpha * 0.6f).toInt(), 0, 0, 0),
                Color.TRANSPARENT
            ),
            null,
            Shader.TileMode.CLAMP
        )
        paint.shader = topGradient
        canvas.drawRect(0f, 0f, w, h * 0.15f, paint)

        // Bottom edge gradient (full screen only)
        if (fullScreen) {
            val bottomGradient = LinearGradient(
                0f, h, 0f, h * 0.85f,
                intArrayOf(
                    Color.argb((baseAlpha * 0.6f).toInt(), 0, 0, 0),
                    Color.TRANSPARENT
                ),
                null,
                Shader.TileMode.CLAMP
            )
            paint.shader = bottomGradient
            canvas.drawRect(0f, h * 0.85f, w, h, paint)
        }

        // --- EFFECT 2: Subtle vignette overlay for contrast boost ---
        paint.shader = null
        val vignetteAlpha = (baseAlpha * 0.15f).toInt().coerceIn(0, 60)
        paint.color = Color.argb(vignetteAlpha, 0, 0, 0)
        canvas.drawRect(0f, 0f, w, h, paint)

        // --- EFFECT 3: Radial center clear zone (keeps center bright and readable) ---
        val radialGradient = RadialGradient(
            w / 2f, h / 2f,
            (w * 0.45f).coerceAtLeast(h * 0.45f),
            intArrayOf(
                Color.TRANSPARENT,
                Color.argb((baseAlpha * 0.25f).toInt(), 0, 0, 0)
            ),
            floatArrayOf(0.3f, 1f),
            Shader.TileMode.CLAMP
        )
        paint.shader = radialGradient
        canvas.drawRect(0f, 0f, w, h, paint)

        paint.shader = null
    }
}
