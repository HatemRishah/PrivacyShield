package com.hatemrishah.privacyshield

import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.annotation.RequiresApi

@RequiresApi(Build.VERSION_CODES.N)
class PrivacyTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        updateTile()
    }

    override fun onClick() {
        super.onClick()
        val prefs = getSharedPreferences(MainActivity.PREFS_NAME, MODE_PRIVATE)
        val currentMode = prefs.getString(MainActivity.KEY_MODE, MainActivity.MODE_OFF)

        // Cycle through: OFF → FULL → NOTIF → OFF
        val nextMode = when (currentMode) {
            MainActivity.MODE_OFF -> MainActivity.MODE_FULL
            MainActivity.MODE_FULL -> MainActivity.MODE_NOTIF
            MainActivity.MODE_NOTIF -> MainActivity.MODE_OFF
            else -> MainActivity.MODE_OFF
        }

        prefs.edit().putString(MainActivity.KEY_MODE, nextMode).apply()

        val intent = Intent(this, OverlayService::class.java).apply {
            putExtra("mode", nextMode)
            putExtra("intensity", prefs.getInt(MainActivity.KEY_INTENSITY, 70))
        }

        if (nextMode == MainActivity.MODE_OFF) {
            stopService(intent)
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
        }

        updateTile()
    }

    private fun updateTile() {
        val prefs = getSharedPreferences(MainActivity.PREFS_NAME, MODE_PRIVATE)
        val mode = prefs.getString(MainActivity.KEY_MODE, MainActivity.MODE_OFF)

        qsTile?.apply {
            when (mode) {
                MainActivity.MODE_FULL -> {
                    state = Tile.STATE_ACTIVE
                    label = "Privacy: Full"
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        subtitle = "Full Screen"
                    }
                }
                MainActivity.MODE_NOTIF -> {
                    state = Tile.STATE_ACTIVE
                    label = "Privacy: Notif"
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        subtitle = "Notifications"
                    }
                }
                else -> {
                    state = Tile.STATE_INACTIVE
                    label = "Privacy Shield"
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        subtitle = "Off"
                    }
                }
            }
            updateTile()
        }
    }
}
