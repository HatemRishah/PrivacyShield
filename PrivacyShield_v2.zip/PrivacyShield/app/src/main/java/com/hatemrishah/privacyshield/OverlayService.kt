package com.hatemrishah.privacyshield

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import androidx.core.app.NotificationCompat

class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var overlayView: PrivacyOverlayView? = null
    private var currentMode: String = MainActivity.MODE_OFF

    companion object {
        const val CHANNEL_ID = "PrivacyShieldChannel"
        const val NOTIF_ID = 1
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val mode = intent?.getStringExtra("mode") ?: MainActivity.MODE_OFF
        val intensity = intent?.getIntExtra("intensity", 70) ?: 70

        currentMode = mode

        when (mode) {
            MainActivity.MODE_FULL -> {
                removeOverlay()
                addOverlay(fullScreen = true, intensity = intensity)
                startForeground(NOTIF_ID, buildNotification(mode))
            }
            MainActivity.MODE_NOTIF -> {
                removeOverlay()
                addOverlay(fullScreen = false, intensity = intensity)
                startForeground(NOTIF_ID, buildNotification(mode))
            }
            MainActivity.MODE_OFF -> {
                removeOverlay()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }

        return START_STICKY
    }

    private fun addOverlay(fullScreen: Boolean, intensity: Int) {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val height = if (fullScreen) {
            WindowManager.LayoutParams.MATCH_PARENT
        } else {
            // Notifications panel height — top ~200dp
            (200 * resources.displayMetrics.density).toInt()
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            height,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
        }

        overlayView = PrivacyOverlayView(this, intensity, fullScreen)

        try {
            windowManager.addView(overlayView, params)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun removeOverlay() {
        overlayView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            overlayView = null
        }
    }

    private fun buildNotification(mode: String): Notification {
        val modeText = when (mode) {
            MainActivity.MODE_FULL -> "Full Screen"
            MainActivity.MODE_NOTIF -> "Notifications Only"
            else -> "Off"
        }

        val offIntent = Intent(this, OverlayService::class.java).apply {
            putExtra("mode", MainActivity.MODE_OFF)
        }
        val offPending = PendingIntent.getService(
            this, 0, offIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val openIntent = Intent(this, MainActivity::class.java)
        val openPending = PendingIntent.getActivity(
            this, 1, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("🛡️ Privacy Shield Active")
            .setContentText("Mode: $modeText — Tap to open app")
            .setSmallIcon(R.drawable.ic_privacy)
            .setContentIntent(openPending)
            .addAction(R.drawable.ic_privacy, "Turn Off", offPending)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Privacy Shield",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Privacy Shield overlay service"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        removeOverlay()
        super.onDestroy()
    }
}
