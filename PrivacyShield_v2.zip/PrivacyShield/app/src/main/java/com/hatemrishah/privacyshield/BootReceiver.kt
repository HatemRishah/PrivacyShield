package com.hatemrishah.privacyshield

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val prefs = context.getSharedPreferences(MainActivity.PREFS_NAME, Context.MODE_PRIVATE)
            val mode = prefs.getString(MainActivity.KEY_MODE, MainActivity.MODE_OFF)

            if (mode != MainActivity.MODE_OFF) {
                val serviceIntent = Intent(context, OverlayService::class.java).apply {
                    putExtra("mode", mode)
                    putExtra("intensity", prefs.getInt(MainActivity.KEY_INTENSITY, 70))
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(serviceIntent)
                } else {
                    context.startService(serviceIntent)
                }
            }
        }
    }
}
